/*import 'package:flutter/material.dart';
import 'package:sapdos_assignment/presentation/pages/doctor_dashboard.dart';
import 'package:sapdos_assignment/presentation/pages/home_screen.dart';
import 'package:sapdos_assignment/presentation/pages/login_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SAPDOS Assignment',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      //home: HomeScreen(), // Set the initial screen
      home: DoctorDashboard(),
    );
  }
}*/

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sapdos_assignment/bloc/appointment/appointment_bloc.dart';
import 'package:sapdos_assignment/bloc/appointment/appointment_event.dart';
import 'package:sapdos_assignment/presentation/pages/doctor_dashboard.dart';
import 'package:sapdos_assignment/repositories/appointment_repository.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appointmentRepository = AppointmentRepository();

    return MultiBlocProvider(
      providers: [
        BlocProvider<AppointmentBloc>(
          create: (context) => AppointmentBloc(appointmentRepository: appointmentRepository)
            ..add(LoadAppointments()),
        ),
      ],
      child: MaterialApp(
        home: DoctorDashboard(),
      ),
    );
  }
}

/*import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sapdos_assignment/presentation/pages/home_screen.dart';
import 'package:sapdos_assignment/presentation/pages/login_page.dart';
import 'package:sapdos_assignment/presentation/pages/registration_screen.dart';
import 'bloc/navigation/navigation_bloc.dart';
import 'presentation/pages/home_screen.dart';
import 'presentation/pages/login_page.dart';
import 'presentation/pages/registration_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => NavigationBloc(),
      child: MaterialApp(
        title: 'SAPDOS',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/',
        routes: {
          '/': (context) => HomeScreen(),
          '/login': (context) => LoginPage(),
          '/register': (context) => RegistrationScreen(),
        },
      ),
    );
  }
} */
/*
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sapdos_assignment/presentation/pages/login_page.dart';
import 'bloc/registration/registration_bloc.dart';
import 'repositories/user_repository.dart';
import 'presentation/pages/registration_screen.dart';

void main() {
  final userRepository = UserRepository();

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider<RegistrationBloc>(
          create: (context) => RegistrationBloc(userRepository: userRepository),
        ),
      ],
      child: MyApp(),
    ),
  );
} */
/*
import 'package:flutter/material.dart';
import 'package:sapdos_assignment/presentation/pages/login_page.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SAPDOS Assignment',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LoginPage(),  // Set the initial screen
    );
  }
} */

/*
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/appointment/appointment_bloc.dart';
import 'repositories/appointment_repository.dart';
import 'presentation/pages/doctor_dashboard.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Doctor Dashboard',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: BlocProvider(
        create: (context) => AppointmentBloc(appointmentRepository: AppointmentRepository()),
        child: DoctorDashboard(),
      ),
    );
  }
} */
