import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sapdos_assignment/presentation/widgets/login_form.dart'; // Import LoginForm
import '../../bloc/login/login_bloc.dart';

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Expanded(
            flex: 2,
            child: Container(
              color: Colors.blue.shade50,
              child: Center(
                child: Image.asset('assets/images/main_image.jpg'), 
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Padding(
              padding: EdgeInsets.all(32.0),
              child: BlocProvider(
                create: (_) => LoginBloc(), // Provide the LoginBloc
                child: LoginForm(), // Use the LoginForm widget
              ),
            ),
          ),
        ],
      ),
    );
  }
}
