import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String buttonText;
  final VoidCallback onPressed;

  CustomButton({required this.buttonText, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white, // Set the background color to white
        foregroundColor: Color(0xFF13235A), // Set the text color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8.0), // Decrease the border radius
          side: BorderSide(color: Color(0xFF13235A)), // Border color
        ),
        padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 24.0), // Padding
      ),
      onPressed: onPressed,
      child: Text(
        buttonText,
        style: TextStyle(
          color: Color(0xFF13235A), // Text color
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
