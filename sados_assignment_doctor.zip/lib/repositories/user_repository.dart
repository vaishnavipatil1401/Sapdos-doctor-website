import '../models/user.dart';

class UserRepository {
  Future<void> registerUser(User user) async {
    // Logic to register user (e.g., API call)
  }
}
