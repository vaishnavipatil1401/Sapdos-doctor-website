class Appointment {
  final String time;
  final String patientName;
  final int age;  // Make sure this field exists in your model
  final bool isCompleted;
  //final int patientAge;

  Appointment({
    required this.time,
    required this.patientName,
    required this.age,  // Make sure this field is initialized
    required this.isCompleted,
   // required this.patientAge,
  });
}
