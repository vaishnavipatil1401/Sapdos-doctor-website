package com.example.sapdos_assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
